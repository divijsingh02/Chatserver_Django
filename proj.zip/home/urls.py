from django.contrib import admin
from django.urls import path
from home import views


urlpatterns = [
    path("",views.index, name='home'),
    path("about",views.about, name='about'),
    path("multiplayer",views.multiplayer, name='multiplayer'),
    path("singleplayer",views.singleplayer, name='singleplayer'),
    path("music",views.music, name='music'),
    path("mp1",views.mp1, name='mp1'),
    path("contact",views.contact, name='contact'),
    path('home',views.home, name='home'),
    path('<str:room>/',views.room, name='room'),
    path('checkview',views.checkview, name='checkview'),
    path('send',views.send, name='send'),
    path('getMessages/<str:room>/',views.getMessages, name='getMessages'),
    




    
    


]