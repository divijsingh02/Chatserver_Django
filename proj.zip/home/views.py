from django.shortcuts import render, HttpResponse, redirect
from home.models import Room, Message, Contact
from django.http import JsonResponse
from datetime import datetime
def index(request):
    return render(request, 'index.html')
# Create your views here.

def about(request):
    return render(request, 'about.html')
def singleplayer(request):
    return render(request, 'Singleplayer.html')

def music(request):
    return render(request, 'music.html')
def contact(request):
    if request.method=="POST":
        email= request.POST.get('email')
        desc= request.POST.get('desc')
        contact= Contact(email=email,desc=desc, date=datetime.today())
        contact.save()
    return render(request, 'contact.html')
def mp1(request):
    return render(request, 'audio.html')
def multiplayer(request):
    return render(request, 'Multiplayer.html')

def home(request):
    return render(request, 'home.html')

def room(request,room):
    username= request.GET.get('username')
    room_details = Room.objects.get(name=room)
    
    return render(request,'room.html',{
        'username':username,
        'room':room,
        'room_details': room_details
    })

def checkview(request):

    room = request.POST['room_name']
    username = request.POST['username']

    if Room.objects.filter(name=room).exists():
        return redirect('/'+room+'/?username='+username)
    else:
        new_room = Room.objects.create(name=room)
        new_room.save()
        return redirect('/'+room+'/?username='+username)
def send(request):
    message=request.POST['message']
    room_id = request.POST['room_id']
    username = request.POST['username']

    new_message= Message.objects.create(value=message, user=username, room=room_id)
    new_message.save()
    return HttpResponse('Message sent successfully')

def getMessages(request,room):
    room_details = Room.objects.get(name=room)
    messages = Message.objects.filter(room=room_details.id)
    return JsonResponse({"messages":list(messages.values())})


